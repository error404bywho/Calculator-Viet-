package test;

import view.CalculatorView;

public class CalculatorTest {
	public static void main(String[] args) {
		CalculatorView.main(null);
	}
}
